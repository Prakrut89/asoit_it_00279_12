<?php
    if(isset($_POST["submit"]))
    {
        if(isset($_POST["in"]) && isset($_POST["in2"]) && isset($_POST["in3"]))
        {
            $i = $_POST["in"];
            $i2 = $_POST["in2"];
            $i3 = $_POST["in3"];
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div class="GG">
        <h3><?php echo $i ?></h3>
        <h3><?php echo $i2 ?></h3>
        <h3><?php echo $i3 ?></h3>
    </div>
</body>
</html>