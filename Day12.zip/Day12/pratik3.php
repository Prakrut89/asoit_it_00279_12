<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        .in{
            display: flex;
            justify-content: center;
            align-items: center;
            margin-top: 10px;
        }
        .in2{
            display: flex;
            justify-content: center;
            align-items: center;
            margin-top: 10px;
            margin-left: -7px;
        }
        .sub{
            display: flex;
            justify-content: center;
            align-items: center;
            margin-top: 10px;
        }
        #subb:hover{
            color: rgb(0, 66, 199);
            box-shadow: 0 0 10px gray;
        }
        .in3{
            display: flex;
            justify-content: center;
            align-items: center;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <form class="container" action="actionfile.php" method="POST">
        <div class="in">
            <h4>Enter Your Name : </h4>
            <input type="text" name="in">&nbsp;&nbsp;
        </div>
        <div class="in2">
            <h4>Gender : &nbsp;</h4>
            <h4>Male&nbsp;&nbsp;</h4>
            <input type="radio" name="in2" value="male">
            <h4>&nbsp;&nbsp;Female&nbsp;&nbsp;</h4>
            <input type="radio" name="in2" value="female">
        </div>
        <div class="in3">
            <h4>Enter Your Age : </h4>
            <input type="Number" name="in3">
        </div>
        <div class="sub">
            <br>
            <input type="submit" name="submit" value="submit" id="subb">
        </div>
    </form>
</body>
</html>